package com.circuit.breaker.example.userservice;

import com.circuit.breaker.example.userservice.dto.OrderDTO;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;


@Service
public class RestService {

    @Autowired
    @Lazy
    private RestTemplate restTemplate;

    @Autowired
    SlowService slowService;


    public static final String USER_SERVICE = "userService";

    private static final String BASEURL = "http://localhost:9191/orders";

    private int attempt = 1;

   // @CircuitBreaker(name = USER_SERVICE, fallbackMethod = "getAllAvailableProducts")
   //  @Bulkhead(name = USER_SERVICE, fallbackMethod = "fallbackMethod")
    @Retry(name = USER_SERVICE, fallbackMethod = "getAllAvailableProducts")
    //@RateLimiter(name = USER_SERVICE)
    public ResponseEntity<List<OrderDTO>> displayOrders(@RequestParam("category") String category) {
        String url = category == null ? BASEURL : BASEURL + "/" + category;
        System.out.println("method called " + attempt++ + " times " + " at " + new Date());
        return new ResponseEntity<List<OrderDTO>>(restTemplate.getForObject(url, ArrayList.class), HttpStatus.OK);
    }

    /*It's important to remember that a fallback method should be placed in the same class and must have
    the same method signature with just ONE extra target exception parameter).

    If there are multiple fallbackMethod methods, the method that has the most closest match will be invoked,

    */
    public ResponseEntity<List<OrderDTO>> getAllAvailableProducts(Exception e) {
        System.out.println("getAllAvailableProducts fallnack method called");
        List<OrderDTO> list = Stream.of(
                new OrderDTO(119, "LED TV", "electronics", "white", 45000),
                new OrderDTO(345, "Headset", "electronics", "black", 7000),
                new OrderDTO(475, "Sound bar", "electronics", "black", 13000),
                new OrderDTO(574, "Puma Shoes", "foot wear", "black & white", 4600),
                new OrderDTO(678, "Vegetable chopper", "kitchen", "blue", 999),
                new OrderDTO(532, "Oven Gloves", "kitchen", "gray", 745)
        ).toList();
        return new ResponseEntity<List<OrderDTO>>(list, HttpStatus.OK);
    }


    public ResponseEntity<List<OrderDTO>> fallbackMethod(Exception e) {
        System.out.println("Fallback method called");
        List<OrderDTO> response = new ArrayList<>();
        return new ResponseEntity<List<OrderDTO>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public ResponseEntity<String> fallbackMethodTimeLimiter(Exception e) {
        System.out.println("fallbackMethodTimeLimiter method called");
        return new ResponseEntity<String>("Default response : Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    //@TimeLimiter(name = USER_SERVICE)
    public CompletableFuture<String> displayOrdersNew(@RequestParam("category") String category) {
        System.out.println("method called " + attempt++ + " times " + " at " + new Date());
        return CompletableFuture.supplyAsync(slowService::slowMethod);
    }
}
